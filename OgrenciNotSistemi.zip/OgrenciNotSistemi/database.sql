﻿-- Öğrenci Not & Ders Bilgi Sistemi Veritabanı Şeması
CREATE DATABASE IF NOT EXISTS `ogrenci_not_sistemi` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ogrenci_not_sistemi`;

SET NAMES utf8mb4;

-- 1. Kullanıcılar Tablosu (Yönetici / Öğretmen)
CREATE TABLE IF NOT EXISTS `kullanicilar` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `kullanici_adi` VARCHAR(50) NOT NULL UNIQUE,
    `sifre` VARCHAR(255) NOT NULL,
    `ad_soyad` VARCHAR(100) NOT NULL,
    `rol` VARCHAR(20) DEFAULT 'admin',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Öğrenciler Tablosu (Öğrenci Girişi ve Bilgileri)
CREATE TABLE IF NOT EXISTS `ogrenciler` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ogr_no` VARCHAR(20) NOT NULL UNIQUE,
    `sifre` VARCHAR(255) NOT NULL DEFAULT '123456',
    `ad` VARCHAR(50) NOT NULL,
    `soyad` VARCHAR(50) NOT NULL,
    `bolum` VARCHAR(100) NOT NULL,
    `sinif` VARCHAR(20) DEFAULT '1. Sınıf',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Dersler Tablosu
CREATE TABLE IF NOT EXISTS `dersler` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ders_kodu` VARCHAR(20) NOT NULL UNIQUE,
    `ders_adi` VARCHAR(100) NOT NULL,
    `kredi` INT DEFAULT 3,
    `ogretmen` VARCHAR(100) DEFAULT 'Dr. Öğr. Üyesi',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Notlar Tablosu
CREATE TABLE IF NOT EXISTS `notlar` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ogrenci_id` INT NOT NULL,
    `ders_id` INT NOT NULL,
    `vize` DECIMAL(5,2) DEFAULT NULL,
    `final` DECIMAL(5,2) DEFAULT NULL,
    `ortalama` DECIMAL(5,2) DEFAULT NULL,
    `harf_notu` VARCHAR(3) DEFAULT NULL,
    `durum` VARCHAR(20) DEFAULT 'Belirsiz',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_notlar_ogrenci` FOREIGN KEY (`ogrenci_id`) REFERENCES `ogrenciler` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_notlar_ders` FOREIGN KEY (`ders_id`) REFERENCES `dersler` (`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_ogr_ders` (`ogrenci_id`, `ders_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Ders Programı Tablosu
CREATE TABLE IF NOT EXISTS `ders_programi` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `ders_id` INT NOT NULL,
    `bolum` VARCHAR(100) NOT NULL,
    `sinif` VARCHAR(20) DEFAULT '1. Sınıf',
    `gun` ENUM('Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi') NOT NULL,
    `baslangic_saati` VARCHAR(10) NOT NULL,
    `bitis_saati` VARCHAR(10) NOT NULL,
    `derslik` VARCHAR(50) NOT NULL,
    `ogretmen` VARCHAR(100) DEFAULT '',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_program_ders` FOREIGN KEY (`ders_id`) REFERENCES `dersler` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Örnek Yönetici (admin / 123456)
INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `sifre`, `ad_soyad`, `rol`) 
VALUES (1, 'admin', '123456', 'Sistem Yöneticisi', 'admin')
ON DUPLICATE KEY UPDATE `ad_soyad`='Sistem Yöneticisi', `sifre`='123456';

-- Örnek Dersler
INSERT INTO `dersler` (`id`, `ders_kodu`, `ders_adi`, `kredi`, `ogretmen`) VALUES
(1, 'MAT101', 'Matematik I', 4, 'Prof. Dr. Kemal Yılmaz'),
(2, 'BLG102', 'Web Tasarımı ve Programlama', 3, 'Doç. Dr. Selin Erdem'),
(3, 'FIZ101', 'Genel Fizik I', 4, 'Prof. Dr. Orhan Şahin'),
(4, 'YAZ201', 'Veri Tabanı Sistemleri', 3, 'Dr. Öğr. Üyesi Burak Kaya'),
(5, 'BLG202', 'Nesne Yönelimli Programlama', 4, 'Doç. Dr. Selin Erdem')
ON DUPLICATE KEY UPDATE `ders_adi`=VALUES(`ders_adi`), `kredi`=VALUES(`kredi`), `ogretmen`=VALUES(`ogretmen`);

-- Örnek Öğrenciler (Şifreleri: 123456)
INSERT INTO `ogrenciler` (`id`, `ogr_no`, `sifre`, `ad`, `soyad`, `bolum`, `sinif`) VALUES
(1, '2024001', '123456', 'Ahmet', 'Yılmaz', 'Bilgisayar Mühendisliği', '2. Sınıf'),
(2, '2024002', '123456', 'Ayşe', 'Demir', 'Bilgisayar Mühendisliği', '2. Sınıf'),
(3, '2024003', '123456', 'Mehmet', 'Kaya', 'Yazılım Mühendisliği', '1. Sınıf'),
(4, '2024004', '123456', 'Zeynep', 'Çelik', 'Bilgisayar Mühendisliği', '3. Sınıf')
ON DUPLICATE KEY UPDATE `ad`=VALUES(`ad`), `soyad`=VALUES(`soyad`), `bolum`=VALUES(`bolum`), `sinif`=VALUES(`sinif`);

-- Örnek Notlar
INSERT INTO `notlar` (`ogrenci_id`, `ders_id`, `vize`, `final`, `ortalama`, `harf_notu`, `durum`) VALUES
(1, 1, 75.00, 85.00, 81.00, 'BA', 'Geçti'),
(1, 2, 90.00, 95.00, 93.00, 'AA', 'Geçti'),
(1, 4, 80.00, 75.00, 77.00, 'BB', 'Geçti'),
(2, 1, 40.00, 45.00, 43.00, 'FF', 'Kaldı'),
(2, 2, 70.00, 80.00, 76.00, 'BB', 'Geçti'),
(3, 1, 60.00, 70.00, 66.00, 'CC', 'Geçti'),
(3, 3, 50.00, 60.00, 56.00, 'CC', 'Geçti')
ON DUPLICATE KEY UPDATE `vize`=VALUES(`vize`), `final`=VALUES(`final`), `ortalama`=VALUES(`ortalama`), `harf_notu`=VALUES(`harf_notu`), `durum`=VALUES(`durum`);

-- Örnek Ders Programı
INSERT INTO `ders_programi` (`id`, `ders_id`, `bolum`, `sinif`, `gun`, `baslangic_saati`, `bitis_saati`, `derslik`, `ogretmen`) VALUES
(1, 1, 'Bilgisayar Mühendisliği', '2. Sınıf', 'Pazartesi', '09:00', '11:45', 'Amfi 1', 'Prof. Dr. Kemal Yılmaz'),
(2, 2, 'Bilgisayar Mühendisliği', '2. Sınıf', 'Salı', '13:00', '15:45', 'Bilgisayar Lab 3', 'Doç. Dr. Selin Erdem'),
(3, 4, 'Bilgisayar Mühendisliği', '2. Sınıf', 'Çarşamba', '10:00', '12:45', 'Derslik 204', 'Dr. Öğr. Üyesi Burak Kaya'),
(4, 5, 'Bilgisayar Mühendisliği', '2. Sınıf', 'Perşembe', '14:00', '16:45', 'Bilgisayar Lab 1', 'Doç. Dr. Selin Erdem'),
(5, 3, 'Bilgisayar Mühendisliği', '2. Sınıf', 'Cuma', '09:00', '11:45', 'Fizik Lab A', 'Prof. Dr. Orhan Şahin'),
(6, 1, 'Yazılım Mühendisliği', '1. Sınıf', 'Pazartesi', '13:00', '15:45', 'Amfi 2', 'Prof. Dr. Kemal Yılmaz'),
(7, 3, 'Yazılım Mühendisliği', '1. Sınıf', 'Çarşamba', '09:00', '11:45', 'Fizik Lab B', 'Prof. Dr. Orhan Şahin')
ON DUPLICATE KEY UPDATE `baslangic_saati`=VALUES(`baslangic_saati`), `bitis_saati`=VALUES(`bitis_saati`), `derslik`=VALUES(`derslik`);
