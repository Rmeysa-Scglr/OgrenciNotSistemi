/**
 * ÖĞRENCİ NOT VE DERS BİLGİ SİSTEMİ - JAVASCRIPT MOTORU
 */

const API_URL = 'api.php';

// Uygulama Durumu (State)
let currentUser = null;
let currentRole = null;
let cachedStudents = [];
let cachedCourses = [];
let cachedGrades = [];
let cachedAdminSchedule = [];

// DOM Yüklendiğinde Başlat
document.addEventListener('DOMContentLoaded', () => {
    initApp();
    setupEventListeners();
});

// ==========================================
// 1. BAŞLANGIÇ & OTURUM KONTROLÜ
// ==========================================
async function initApp() {
    try {
        const res = await fetch(`${API_URL}?action=check_auth`);
        const data = await res.json();

        if (data.status === 'success' && data.authenticated) {
            currentUser = data.user;
            currentRole = data.role;

            if (currentRole === 'admin') {
                showAdminView();
            } else if (currentRole === 'student') {
                showStudentView();
            }
        } else {
            showLoginView();
        }
    } catch (err) {
        console.error('Oturum kontrol hatası:', err);
        showLoginView();
    }
}

function setupEventListeners() {
    // Giriş Formu
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Modal dışına tıklayınca kapatma
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal-overlay')) {
            e.target.classList.remove('active');
        }
    });
}

// ==========================================
// 2. GÖRÜNÜM GEÇİŞLERİ (VIEW SWITCHER)
// ==========================================
function showLoginView() {
    document.getElementById('authSection').style.display = 'flex';
    document.getElementById('adminSection').style.display = 'none';
    document.getElementById('studentSection').style.display = 'none';
}

function showAdminView() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('studentSection').style.display = 'none';
    document.getElementById('adminSection').style.display = 'flex';

    if (currentUser) {
        document.getElementById('adminName').textContent = currentUser.ad_soyad || 'Sistem Yöneticisi';
    }

    // Admin verilerini yükle
    loadAdminStats();
    loadGrades();
    loadStudents();
    loadCourses();
    loadAdminSchedule();
}

function showStudentView() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('adminSection').style.display = 'none';
    document.getElementById('studentSection').style.display = 'flex';

    if (currentUser) {
        document.getElementById('studentPortalName').textContent = currentUser.ad_soyad || 'Öğrenci';
    }

    // Öğrenci verilerini yükle
    loadStudentPortalData();
}

// ==========================================
// 3. GİRİŞ & ÇIKIŞ İŞLEMLERİ
// ==========================================
function switchLoginRole(role) {
    const roleInput = document.getElementById('loginRole');
    const tabStudent = document.getElementById('tabStudentBtn');
    const tabAdmin = document.getElementById('tabAdminBtn');
    const usernameLabel = document.getElementById('usernameLabel');
    const usernameInput = document.getElementById('loginUsername');
    const usernameIcon = document.getElementById('usernameIcon');
    const authTitle = document.getElementById('authTitle');

    roleInput.value = role;

    if (role === 'student') {
        tabStudent.classList.add('active');
        tabAdmin.classList.remove('active');
        usernameLabel.textContent = 'Öğrenci Numarası';
        usernameInput.placeholder = 'Örn: 2024001';
        usernameIcon.textContent = '🆔';
        authTitle.textContent = 'Öğrenci Portalı Girişi';
    } else {
        tabAdmin.classList.add('active');
        tabStudent.classList.remove('active');
        usernameLabel.textContent = 'Yönetici Kullanıcı Adı';
        usernameInput.placeholder = 'Örn: admin';
        usernameIcon.textContent = '👤';
        authTitle.textContent = 'Yönetici Paneli Girişi';
    }
}

function quickFill(role, user, pass) {
    switchLoginRole(role);
    document.getElementById('loginUsername').value = user;
    document.getElementById('loginPassword').value = pass;
}

async function handleLogin(e) {
    e.preventDefault();
    const role = document.getElementById('loginRole').value;
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    const submitBtn = document.getElementById('loginSubmitBtn');

    if (!username || !password) {
        showToast('Lütfen tüm alanları doldurunuz.', 'error');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Giriş Yapılıyor...';

    const formData = new FormData();
    formData.append('action', 'login');
    formData.append('role', role);
    formData.append('username', username);
    formData.append('password', password);

    try {
        const res = await fetch(API_URL, {
            method: 'POST',
            body: formData
        });
        const data = await res.json();

        if (data.status === 'success') {
            showToast(data.message || 'Giriş başarılı!', 'success');
            currentUser = data.user;
            currentRole = data.role;

            if (currentRole === 'admin') {
                showAdminView();
            } else {
                showStudentView();
            }
        } else {
            showToast(data.message || 'Kullanıcı adı veya şifre hatalı!', 'error');
        }
    } catch (err) {
        showToast('Sunucu bağlantı hatası oluştu.', 'error');
        console.error(err);
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>Giriş Yap</span> &rarr;';
    }
}

async function logout() {
    try {
        await fetch(`${API_URL}?action=logout`);
        currentUser = null;
        currentRole = null;
        showToast('Başarıyla çıkış yapıldı.', 'info');
        showLoginView();
    } catch (err) {
        console.error(err);
        showLoginView();
    }
}

// ==========================================
// 4. YÖNETİCİ PANELİ İŞLEMLERİ (ADMIN)
// ==========================================
function switchAdminTab(tabId) {
    document.querySelectorAll('#adminSection .tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
    });

    document.querySelectorAll('#adminSection .tab-content').forEach(tab => {
        tab.classList.toggle('active', tab.id === tabId);
    });
}

// İstatistikleri Yükle
async function loadAdminStats() {
    try {
        const res = await fetch(`${API_URL}?action=get_stats`);
        const json = await res.json();

        if (json.status === 'success' && json.data) {
            const d = json.data;
            document.getElementById('statStudents').textContent = d.totalStudents || 0;
            document.getElementById('statCourses').textContent = d.totalCourses || 0;
            document.getElementById('statAvg').textContent = d.avgGrade ? d.avgGrade.toFixed(2) : '0.00';
            document.getElementById('statPassed').textContent = d.passed || 0;
            document.getElementById('statFailed').textContent = d.failed || 0;
        }
    } catch (err) {
        console.error('İstatistik hatası:', err);
    }
}

// --- NOT YÖNETİMİ ---
async function loadGrades() {
    try {
        const res = await fetch(`${API_URL}?action=get_grades`);
        const json = await res.json();

        if (json.status === 'success') {
            cachedGrades = json.data || [];
            renderGradesTable(cachedGrades);
        }
    } catch (err) {
        console.error('Notları yükleme hatası:', err);
    }
}

function renderGradesTable(grades) {
    const tbody = document.getElementById('gradesTableBody');
    if (!grades || grades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" style="text-align: center; color: var(--text-dim);">Kayıtlı not bulunamadı.</td></tr>';
        return;
    }

    tbody.innerHTML = grades.map(g => {
        const statusBadge = g.durum === 'Geçti' 
            ? '<span class="badge badge-success">✓ Geçti</span>' 
            : (g.durum === 'Kaldı' ? '<span class="badge badge-danger">✕ Kaldı</span>' : '<span class="badge badge-warning">Belirsiz</span>');

        const vizeDisplay = g.vize !== null ? parseFloat(g.vize).toFixed(1) : '-';
        const finalDisplay = g.final !== null ? parseFloat(g.final).toFixed(1) : '-';
        const ortDisplay = g.ortalama !== null ? parseFloat(g.ortalama).toFixed(2) : '-';
        const harfDisplay = g.harf_notu ? `<span class="grade-badge">${g.harf_notu}</span>` : '-';

        return `
            <tr>
                <td><strong>${escapeHtml(g.ogr_no)}</strong></td>
                <td>${escapeHtml(g.ad)} ${escapeHtml(g.soyad)}</td>
                <td><small style="color: var(--text-dim);">${escapeHtml(g.bolum)} (${escapeHtml(g.sinif)})</small></td>
                <td><strong>${escapeHtml(g.ders_kodu)}</strong> - ${escapeHtml(g.ders_adi)}</td>
                <td>${vizeDisplay}</td>
                <td>${finalDisplay}</td>
                <td><strong>${ortDisplay}</strong></td>
                <td>${harfDisplay}</td>
                <td>${statusBadge}</td>
                <td>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn btn-secondary btn-sm" title="Düzenle" onclick="openGradeModalForEdit(${g.ogrenci_id}, ${g.ders_id}, '${g.vize || ''}', '${g.final || ''}')">✏️</button>
                        <button class="btn btn-danger btn-sm" title="Sil" onclick="deleteGrade(${g.id})">🗑️</button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function filterGradesTable() {
    const q = document.getElementById('gradeSearchInput').value.toLowerCase();
    const filtered = cachedGrades.filter(g => 
        (g.ogr_no && g.ogr_no.toLowerCase().includes(q)) ||
        (g.ad && g.ad.toLowerCase().includes(q)) ||
        (g.soyad && g.soyad.toLowerCase().includes(q)) ||
        (g.ders_kodu && g.ders_kodu.toLowerCase().includes(q)) ||
        (g.ders_adi && g.ders_adi.toLowerCase().includes(q))
    );
    renderGradesTable(filtered);
}

function openGradeModal() {
    populateGradeSelects();
    document.getElementById('gradeVize').value = '';
    document.getElementById('gradeFinal').value = '';
    document.getElementById('gradePreviewText').textContent = '-';
    openModal('gradeModal');
}

function openGradeModalForEdit(ogrenciId, dersId, vize, final) {
    populateGradeSelects();
    document.getElementById('gradeStudentSelect').value = ogrenciId;
    document.getElementById('gradeCourseSelect').value = dersId;
    document.getElementById('gradeVize').value = vize;
    document.getElementById('gradeFinal').value = final;
    calculateGradePreview();
    openModal('gradeModal');
}

function populateGradeSelects() {
    const stSelect = document.getElementById('gradeStudentSelect');
    const crsSelect = document.getElementById('gradeCourseSelect');

    stSelect.innerHTML = '<option value="">Öğrenci Seçiniz...</option>' + 
        cachedStudents.map(s => `<option value="${s.id}">${s.ogr_no} - ${s.ad} ${s.soyad} (${s.bolum})</option>`).join('');

    crsSelect.innerHTML = '<option value="">Ders Seçiniz...</option>' + 
        cachedCourses.map(c => `<option value="${c.id}">${c.ders_kodu} - ${c.ders_adi} (${c.kredi} Kredi)</option>`).join('');
}

function calculateGradePreview() {
    const vizeVal = document.getElementById('gradeVize').value;
    const finalVal = document.getElementById('gradeFinal').value;
    const preview = document.getElementById('gradePreviewText');

    if (vizeVal === '' || finalVal === '') {
        preview.textContent = '-';
        return;
    }

    const v = parseFloat(vizeVal);
    const f = parseFloat(finalVal);
    const ort = Math.round(((v * 0.4) + (f * 0.6)) * 100) / 100;

    let harf = 'FF';
    if (ort >= 90) harf = 'AA';
    else if (ort >= 85) harf = 'BA';
    else if (ort >= 80) harf = 'BB';
    else if (ort >= 75) harf = 'CB';
    else if (ort >= 65) harf = 'CC';
    else if (ort >= 58) harf = 'DC';
    else if (ort >= 50) harf = 'DD';

    const durum = (ort >= 50 && f >= 50) ? 'Geçti' : 'Kaldı';
    const color = durum === 'Geçti' ? 'var(--success)' : 'var(--danger)';

    preview.innerHTML = `Ort: <strong>${ort.toFixed(2)}</strong> | Harf: <strong>${harf}</strong> | <span style="color: ${color}">[${durum}]</span>`;
}

async function handleSaveGrade(e) {
    e.preventDefault();
    const ogrenci_id = document.getElementById('gradeStudentSelect').value;
    const ders_id = document.getElementById('gradeCourseSelect').value;
    const vize = document.getElementById('gradeVize').value;
    const final = document.getElementById('gradeFinal').value;

    const fd = new FormData();
    fd.append('action', 'save_grade');
    fd.append('ogrenci_id', ogrenci_id);
    fd.append('ders_id', ders_id);
    fd.append('vize', vize);
    fd.append('final', final);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();

        if (data.status === 'success') {
            showToast(data.message || 'Not kaydedildi!', 'success');
            closeModal('gradeModal');
            loadGrades();
            loadAdminStats();
        } else {
            showToast(data.message || 'Not kaydedilemedi!', 'error');
        }
    } catch (err) {
        showToast('Sunucu bağlantı hatası!', 'error');
    }
}

async function deleteGrade(id) {
    if (!confirm('Bu not kaydını silmek istediğinize emin misiniz?')) return;

    const fd = new FormData();
    fd.append('action', 'delete_grade');
    fd.append('id', id);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Not kaydı silindi.', 'success');
            loadGrades();
            loadAdminStats();
        } else {
            showToast(data.message || 'Silme işlemi başarısız!', 'error');
        }
    } catch (err) {
        showToast('Hata oluştu.', 'error');
    }
}

// --- DERS PROGRAMI YÖNETİMİ ---
async function loadAdminSchedule() {
    const dept = document.getElementById('scheduleDeptFilter').value;
    const sinif = document.getElementById('scheduleClassFilter').value;

    let url = `${API_URL}?action=get_schedule`;
    if (dept) url += `&bolum=${encodeURIComponent(dept)}`;
    if (sinif) url += `&sinif=${encodeURIComponent(sinif)}`;

    try {
        const res = await fetch(url);
        const json = await res.json();

        if (json.status === 'success') {
            cachedAdminSchedule = json.data || [];
            renderScheduleGrid('adminScheduleGrid', cachedAdminSchedule, true);
        }
    } catch (err) {
        console.error('Ders programı yükleme hatası:', err);
    }
}

function renderScheduleGrid(containerId, scheduleList, isAdmin = false) {
    const days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma'];
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = days.map(day => {
        const dayItems = scheduleList.filter(s => s.gun === day);
        
        let cardsHtml = '';
        if (dayItems.length === 0) {
            cardsHtml = '<div style="font-size: 12px; color: var(--text-dim); text-align: center; margin-top: 30px;">Ders yok</div>';
        } else {
            cardsHtml = dayItems.map(item => {
                const deleteBtn = isAdmin ? `<button class="schedule-delete-btn" title="Sil" onclick="deleteSchedule(${item.id})">×</button>` : '';
                return `
                    <div class="schedule-card">
                        ${deleteBtn}
                        <div class="schedule-time">⏱️ ${escapeHtml(item.baslangic_saati)} - ${escapeHtml(item.bitis_saati)}</div>
                        <div class="schedule-name">${escapeHtml(item.ders_kodu)}: ${escapeHtml(item.ders_adi)}</div>
                        <div class="schedule-meta">
                            📍 <strong>${escapeHtml(item.derslik)}</strong><br>
                            👨‍🏫 ${escapeHtml(item.ogretmen || 'Öğr. Gör.')}<br>
                            <span style="opacity: 0.8;">${escapeHtml(item.bolum)} (${escapeHtml(item.sinif)})</span>
                        </div>
                    </div>
                `;
            }).join('');
        }

        return `
            <div class="day-column">
                <div class="day-header">${day} (${dayItems.length} Ders)</div>
                <div class="day-body">${cardsHtml}</div>
            </div>
        `;
    }).join('');
}

function openScheduleModal() {
    const select = document.getElementById('schedCourseSelect');
    select.innerHTML = '<option value="">Ders Seçiniz...</option>' + 
        cachedCourses.map(c => `<option value="${c.id}">${c.ders_kodu} - ${c.ders_adi}</option>`).join('');
    openModal('scheduleModal');
}

async function handleSaveSchedule(e) {
    e.preventDefault();
    const ders_id = document.getElementById('schedCourseSelect').value;
    const bolum = document.getElementById('schedDept').value.trim();
    const sinif = document.getElementById('schedClass').value;
    const gun = document.getElementById('schedDay').value;
    const baslangic_saati = document.getElementById('schedStart').value;
    const bitis_saati = document.getElementById('schedEnd').value;
    const derslik = document.getElementById('schedRoom').value.trim();
    const ogretmen = document.getElementById('schedTeacher').value.trim();

    const fd = new FormData();
    fd.append('action', 'add_schedule');
    fd.append('ders_id', ders_id);
    fd.append('bolum', bolum);
    fd.append('sinif', sinif);
    fd.append('gun', gun);
    fd.append('baslangic_saati', baslangic_saati);
    fd.append('bitis_saati', bitis_saati);
    fd.append('derslik', derslik);
    fd.append('ogretmen', ogretmen);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Ders programı başarıyla eklendi!', 'success');
            closeModal('scheduleModal');
            loadAdminSchedule();
        } else {
            showToast(data.message || 'Eklenemedi!', 'error');
        }
    } catch (err) {
        showToast('Bağlantı hatası.', 'error');
    }
}

async function deleteSchedule(id) {
    if (!confirm('Bu ders programı kaydını silmek istediğinize emin misiniz?')) return;

    const fd = new FormData();
    fd.append('action', 'delete_schedule');
    fd.append('id', id);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Ders programı silindi.', 'success');
            loadAdminSchedule();
        } else {
            showToast(data.message || 'Silme başarısız.', 'error');
        }
    } catch (err) {
        showToast('Hata oluştu.', 'error');
    }
}

// --- ÖĞRENCİ YÖNETİMİ ---
async function loadStudents() {
    try {
        const res = await fetch(`${API_URL}?action=get_students`);
        const json = await res.json();
        if (json.status === 'success') {
            cachedStudents = json.data || [];
            renderStudentsTable(cachedStudents);
        }
    } catch (err) {
        console.error('Öğrenci yükleme hatası:', err);
    }
}

function renderStudentsTable(students) {
    const tbody = document.getElementById('studentsTableBody');
    if (!students || students.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-dim);">Öğrenci bulunamadı.</td></tr>';
        return;
    }

    tbody.innerHTML = students.map(s => `
        <tr>
            <td><strong>${escapeHtml(s.ogr_no)}</strong></td>
            <td>${escapeHtml(s.ad)} ${escapeHtml(s.soyad)}</td>
            <td>${escapeHtml(s.bolum)}</td>
            <td><span class="badge badge-info">${escapeHtml(s.sinif || '1. Sınıf')}</span></td>
            <td><small style="color: var(--text-dim);">${s.created_at ? s.created_at.split(' ')[0] : '-'}</small></td>
            <td>
                <button class="btn btn-danger btn-sm" onclick="deleteStudent(${s.id})">Sil</button>
            </td>
        </tr>
    `).join('');
}

function filterStudentsTable() {
    const q = document.getElementById('studentSearchInput').value.toLowerCase();
    const filtered = cachedStudents.filter(s => 
        (s.ogr_no && s.ogr_no.toLowerCase().includes(q)) ||
        (s.ad && s.ad.toLowerCase().includes(q)) ||
        (s.soyad && s.soyad.toLowerCase().includes(q)) ||
        (s.bolum && s.bolum.toLowerCase().includes(q))
    );
    renderStudentsTable(filtered);
}

function openStudentModal() {
    document.getElementById('studentForm').reset();
    openModal('studentModal');
}

async function handleSaveStudent(e) {
    e.preventDefault();
    const ogr_no = document.getElementById('stNum').value.trim();
    const ad = document.getElementById('stName').value.trim();
    const soyad = document.getElementById('stSurname').value.trim();
    const bolum = document.getElementById('stDept').value.trim();
    const sinif = document.getElementById('stClass').value;
    const sifre = document.getElementById('stPass').value.trim();

    const fd = new FormData();
    fd.append('action', 'add_student');
    fd.append('ogr_no', ogr_no);
    fd.append('ad', ad);
    fd.append('soyad', soyad);
    fd.append('bolum', bolum);
    fd.append('sinif', sinif);
    fd.append('sifre', sifre);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Öğrenci başarıyla eklendi!', 'success');
            closeModal('studentModal');
            loadStudents();
            loadAdminStats();
        } else {
            showToast(data.message || 'Öğrenci eklenemedi.', 'error');
        }
    } catch (err) {
        showToast('Bağlantı hatası.', 'error');
    }
}

async function deleteStudent(id) {
    if (!confirm('Öğrenciyi ve bağlı tüm not kayıtlarını silmek istediğinize emin misiniz?')) return;

    const fd = new FormData();
    fd.append('action', 'delete_student');
    fd.append('id', id);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Öğrenci silindi.', 'success');
            loadStudents();
            loadGrades();
            loadAdminStats();
        } else {
            showToast(data.message || 'Silme işlemi başarısız.', 'error');
        }
    } catch (err) {
        showToast('Hata oluştu.', 'error');
    }
}

// --- DERS YÖNETİMİ ---
async function loadCourses() {
    try {
        const res = await fetch(`${API_URL}?action=get_courses`);
        const json = await res.json();
        if (json.status === 'success') {
            cachedCourses = json.data || [];
            renderCoursesTable(cachedCourses);
        }
    } catch (err) {
        console.error('Ders yükleme hatası:', err);
    }
}

function renderCoursesTable(courses) {
    const tbody = document.getElementById('coursesTableBody');
    if (!courses || courses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--text-dim);">Ders bulunamadı.</td></tr>';
        return;
    }

    tbody.innerHTML = courses.map(c => `
        <tr>
            <td><strong>${escapeHtml(c.ders_kodu)}</strong></td>
            <td>${escapeHtml(c.ders_adi)}</td>
            <td><span class="badge badge-info">${c.kredi} Kredi</span></td>
            <td>${escapeHtml(c.ogretmen || 'Dr. Öğr. Üyesi')}</td>
            <td>
                <button class="btn btn-danger btn-sm" onclick="deleteCourse(${c.id})">Sil</button>
            </td>
        </tr>
    `).join('');
}

function filterCoursesTable() {
    const q = document.getElementById('courseSearchInput').value.toLowerCase();
    const filtered = cachedCourses.filter(c => 
        (c.ders_kodu && c.ders_kodu.toLowerCase().includes(q)) ||
        (c.ders_adi && c.ders_adi.toLowerCase().includes(q))
    );
    renderCoursesTable(filtered);
}

function openCourseModal() {
    document.getElementById('courseForm').reset();
    openModal('courseModal');
}

async function handleSaveCourse(e) {
    e.preventDefault();
    const ders_kodu = document.getElementById('cCode').value.trim();
    const ders_adi = document.getElementById('cName').value.trim();
    const kredi = document.getElementById('cCredit').value;
    const ogretmen = document.getElementById('cTeacher').value.trim();

    const fd = new FormData();
    fd.append('action', 'add_course');
    fd.append('ders_kodu', ders_kodu);
    fd.append('ders_adi', ders_adi);
    fd.append('kredi', kredi);
    fd.append('ogretmen', ogretmen);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Ders başarıyla eklendi!', 'success');
            closeModal('courseModal');
            loadCourses();
            loadAdminStats();
        } else {
            showToast(data.message || 'Ders eklenemedi.', 'error');
        }
    } catch (err) {
        showToast('Bağlantı hatası.', 'error');
    }
}

async function deleteCourse(id) {
    if (!confirm('Dersi ve ilgili tüm notları silmek istediğinize emin misiniz?')) return;

    const fd = new FormData();
    fd.append('action', 'delete_course');
    fd.append('id', id);

    try {
        const res = await fetch(API_URL, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Ders silindi.', 'success');
            loadCourses();
            loadGrades();
            loadAdminStats();
        } else {
            showToast(data.message || 'Silme işlemi başarısız.', 'error');
        }
    } catch (err) {
        showToast('Hata oluştu.', 'error');
    }
}

// ==========================================
// 5. ÖĞRENCİ PORTAL İŞLEMLERİ (STUDENT)
// ==========================================
function switchStudentTab(tabId) {
    document.getElementById('stTabBtnGrades').classList.toggle('active', tabId === 'st-grades');
    document.getElementById('stTabBtnSchedule').classList.toggle('active', tabId === 'st-schedule');

    document.getElementById('st-grades').classList.toggle('active', tabId === 'st-grades');
    document.getElementById('st-schedule').classList.toggle('active', tabId === 'st-schedule');
}

async function loadStudentPortalData() {
    try {
        const res = await fetch(`${API_URL}?action=get_student_portal_data`);
        const json = await res.json();

        if (json.status === 'success') {
            const st = json.student;
            document.getElementById('studentCardFullName').textContent = st.ad_soyad || 'Öğrenci';
            document.getElementById('studentCardNo').textContent = st.ogr_no || '-';
            document.getElementById('studentCardDept').textContent = st.bolum || '-';
            document.getElementById('studentCardClass').textContent = st.sinif || '1. Sınıf';
            document.getElementById('studentCardGPA').textContent = st.gpa || '0.00';
            document.getElementById('studentCardCredits').textContent = st.toplamKredi || '0';

            // Notları Doldur
            renderStudentGrades(json.grades || []);

            // Ders Programını Doldur
            renderScheduleGrid('studentScheduleGrid', json.schedule || [], false);
        } else {
            showToast(json.message || 'Öğrenci bilgileri alınamadı.', 'error');
        }
    } catch (err) {
        console.error('Öğrenci portal hatası:', err);
    }
}

function renderStudentGrades(grades) {
    const tbody = document.getElementById('studentGradesBody');
    if (!grades || grades.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align: center; color: var(--text-dim);">Henüz not girişi yapılmamış ders bulunmamaktadır.</td></tr>';
        return;
    }

    tbody.innerHTML = grades.map(g => {
        const statusBadge = g.durum === 'Geçti' 
            ? '<span class="badge badge-success">✓ Geçti</span>' 
            : (g.durum === 'Kaldı' ? '<span class="badge badge-danger">✕ Kaldı</span>' : '<span class="badge badge-warning">Açıklanmadı</span>');

        const vizeDisplay = g.vize !== null ? parseFloat(g.vize).toFixed(1) : '-';
        const finalDisplay = g.final !== null ? parseFloat(g.final).toFixed(1) : '-';
        const ortDisplay = g.ortalama !== null ? parseFloat(g.ortalama).toFixed(2) : '-';
        const harfDisplay = g.harf_notu ? `<span class="grade-badge">${g.harf_notu}</span>` : '-';

        return `
            <tr>
                <td><strong>${escapeHtml(g.ders_kodu)}</strong></td>
                <td>${escapeHtml(g.ders_adi)}</td>
                <td><span class="badge badge-info">${g.kredi} Kredi</span></td>
                <td><small style="color: var(--text-muted);">${escapeHtml(g.ogretmen || 'Öğr. Gör.')}</small></td>
                <td>${vizeDisplay}</td>
                <td>${finalDisplay}</td>
                <td><strong>${ortDisplay}</strong></td>
                <td>${harfDisplay}</td>
                <td>${statusBadge}</td>
            </tr>
        `;
    }).join('');
}

// ==========================================
// 6. YARDIMCI VE BİLDİRİM FONKSİYONLARI
// ==========================================
function openModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('active');
}

function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('active');
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    else if (type === 'error') icon = '❌';

    toast.innerHTML = `<span>${icon}</span> <span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}