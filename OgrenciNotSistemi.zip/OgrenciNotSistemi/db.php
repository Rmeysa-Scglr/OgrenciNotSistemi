<?php
// UTF-8 ve Hata Ayarları
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$dbname = 'ogrenci_not_sistemi';
$username = 'root';
$password = '';

try {
    // Önce sunucuya bağlan (veritabanı yoksa oluşturmak için)
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Veritabanını oluştur ve seç
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$dbname`");
    $pdo->exec("SET NAMES utf8mb4");

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Veritabanı bağlantı hatası: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Not, Ortalama ve Harf Notu Hesaplama Fonksiyonu
function hesaplaNot($vize, $final) {
    if ($vize === null || $vize === '' || $final === null || $final === '') {
        return [
            'ortalama' => null,
            'harf' => null,
            'durum' => 'Belirsiz'
        ];
    }

    $v = floatval($vize);
    $f = floatval($final);
    
    // %40 Vize + %60 Final
    $ort = round(($v * 0.40) + ($f * 0.60), 2);

    if ($ort >= 90) $harf = 'AA';
    elseif ($ort >= 85) $harf = 'BA';
    elseif ($ort >= 80) $harf = 'BB';
    elseif ($ort >= 75) $harf = 'CB';
    elseif ($ort >= 65) $harf = 'CC';
    elseif ($ort >= 58) $harf = 'DC';
    elseif ($ort >= 50) $harf = 'DD';
    else $harf = 'FF';

    // Geçme barajı: Ortalama >= 50 ve Final >= 50
    $durum = ($ort >= 50 && $f >= 50) ? 'Geçti' : 'Kaldı';

    return [
        'ortalama' => $ort,
        'harf' => $harf,
        'durum' => $durum
    ];
}
