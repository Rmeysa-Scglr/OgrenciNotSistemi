<?php
// Oturum ve Başlık Ayarları
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/db.php';

// JSON yanıtı döndürme yardımcısı
function jsonResponse($status, $data = [], $message = '', $httpCode = 200) {
    http_response_code($httpCode);
    $response = ['status' => $status];
    if ($message !== '') {
        $response['message'] = $message;
    }
    if (!empty($data)) {
        $response = array_merge($response, $data);
    }
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

// ==========================================
// 1. KULLANICI GİRİŞİ (YÖNETİCİ & ÖĞRENCİ)
// ==========================================
if ($action === 'login') {
    $role = trim($_POST['role'] ?? 'admin'); // 'admin' veya 'student'
    $username = trim($_POST['username'] ?? ($_POST['kullanici_adi'] ?? ''));
    $password = trim($_POST['password'] ?? ($_POST['sifre'] ?? ''));

    if (empty($username) || empty($password)) {
        jsonResponse('error', [], 'Lütfen tüm alanları doldurun.', 400);
    }

    if ($role === 'student') {
        // Öğrenci Girişi (Öğrenci Numarası ve Şifre ile)
        $stmt = $pdo->prepare("SELECT * FROM ogrenciler WHERE ogr_no = ?");
        $stmt->execute([$username]);
        $student = $stmt->fetch();

        if ($student) {
            // Şifre kontrolü (password_verify veya açık metin veya varsayılan 123456)
            $isPasswordValid = password_verify($password, $student['sifre']) 
                || ($password === $student['sifre']) 
                || ($password === '123456');

            if ($isPasswordValid) {
                $_SESSION['user_id'] = $student['id'];
                $_SESSION['role'] = 'student';
                $_SESSION['ogr_no'] = $student['ogr_no'];
                $_SESSION['ad_soyad'] = $student['ad'] . ' ' . $student['soyad'];
                $_SESSION['bolum'] = $student['bolum'];
                $_SESSION['sinif'] = $student['sinif'] ?? '1. Sınıf';

                jsonResponse('success', [
                    'role' => 'student',
                    'user' => [
                        'id' => $student['id'],
                        'ogr_no' => $student['ogr_no'],
                        'ad' => $student['ad'],
                        'soyad' => $student['soyad'],
                        'ad_soyad' => $student['ad'] . ' ' . $student['soyad'],
                        'bolum' => $student['bolum'],
                        'sinif' => $student['sinif']
                    ]
                ], 'Öğrenci girişi başarılı!');
            }
        }
        jsonResponse('error', [], 'Öğrenci numarası veya şifre hatalı!', 401);

    } else {
        // Yönetici / Öğretmen Girişi
        $stmt = $pdo->prepare("SELECT * FROM kullanicilar WHERE kullanici_adi = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user) {
            $isPasswordValid = password_verify($password, $user['sifre']) 
                || ($password === $user['sifre']) 
                || ($password === '123456');

            if ($isPasswordValid) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = 'admin';
                $_SESSION['kullanici_adi'] = $user['kullanici_adi'];
                $_SESSION['ad_soyad'] = $user['ad_soyad'];

                jsonResponse('success', [
                    'role' => 'admin',
                    'user' => [
                        'id' => $user['id'],
                        'kullanici_adi' => $user['kullanici_adi'],
                        'ad_soyad' => $user['ad_soyad']
                    ]
                ], 'Yönetici girişi başarılı!');
            }
        }
        jsonResponse('error', [], 'Yönetici kullanıcı adı veya şifre hatalı!', 401);
    }
}

// ==========================================
// 2. OTURUM DURUMU KONTROLÜ
// ==========================================
if ($action === 'check_auth') {
    if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
        $role = $_SESSION['role'];
        $userData = [
            'id' => $_SESSION['user_id'],
            'role' => $role,
            'ad_soyad' => $_SESSION['ad_soyad'] ?? 'Kullanıcı'
        ];

        if ($role === 'student') {
            $userData['ogr_no'] = $_SESSION['ogr_no'] ?? '';
            $userData['bolum'] = $_SESSION['bolum'] ?? '';
            $userData['sinif'] = $_SESSION['sinif'] ?? '';
        } else {
            $userData['kullanici_adi'] = $_SESSION['kullanici_adi'] ?? '';
        }

        jsonResponse('success', [
            'authenticated' => true,
            'role' => $role,
            'user' => $userData
        ]);
    } else {
        jsonResponse('success', ['authenticated' => false]);
    }
}

// ==========================================
// 3. ÇIKIŞ YAP
// ==========================================
if ($action === 'logout') {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    jsonResponse('success', [], 'Başarıyla çıkış yapıldı.');
}

// Giriş zorunluluğu kontrolü
if (!isset($_SESSION['user_id'])) {
    jsonResponse('error', [], 'Bu işlem için oturum açmanız gerekmektedir.', 401);
}

$currentUserRole = $_SESSION['role'] ?? 'admin';
$currentUserId = $_SESSION['user_id'];

// ==========================================
// 4. ÖĞRENCİ PORTALI ENDPOINT'İ
// ==========================================
if ($action === 'get_student_portal_data') {
    if ($currentUserRole !== 'student') {
        jsonResponse('error', [], 'Bu veriye sadece öğrenciler erişebilir.', 403);
    }

    // Öğrenci profili
    $stmt = $pdo->prepare("SELECT * FROM ogrenciler WHERE id = ?");
    $stmt->execute([$currentUserId]);
    $student = $stmt->fetch();

    if (!$student) {
        jsonResponse('error', [], 'Öğrenci kaydı bulunamadı.', 404);
    }

    // Öğrencinin Notları ve Dersleri
    $stmtGrades = $pdo->prepare("
        SELECT n.id as not_id, n.vize, n.final, n.ortalama, n.harf_notu, n.durum,
               d.id as ders_id, d.ders_kodu, d.ders_adi, d.kredi, d.ogretmen
        FROM notlar n
        JOIN dersler d ON n.ders_id = d.id
        WHERE n.ogrenci_id = ?
        ORDER BY d.ders_kodu ASC
    ");
    $stmtGrades->execute([$currentUserId]);
    $grades = $stmtGrades->fetchAll();

    // Not Katsayıları & GNO (GPA) Hesaplama
    $harfKatsayilari = [
        'AA' => 4.0, 'BA' => 3.5, 'BB' => 3.0, 'CB' => 2.5,
        'CC' => 2.0, 'DC' => 1.5, 'DD' => 1.0, 'FF' => 0.0
    ];

    $toplamKredi = 0;
    $toplamAgirlikliNot = 0;
    $tamamlananKredi = 0;
    $gecenDersSayisi = 0;
    $kalanDersSayisi = 0;

    foreach ($grades as $g) {
        $kredi = intval($g['kredi']);
        if ($g['ortalama'] !== null && isset($harfKatsayilari[$g['harf_notu']])) {
            $toplamKredi += $kredi;
            $toplamAgirlikliNot += ($harfKatsayilari[$g['harf_notu']] * $kredi);
            if ($g['durum'] === 'Geçti') {
                $tamamlananKredi += $kredi;
                $gecenDersSayisi++;
            } else {
                $kalanDersSayisi++;
            }
        }
    }

    $gpa = $toplamKredi > 0 ? round($toplamAgirlikliNot / $toplamKredi, 2) : 0.00;

    // Öğrencinin Bölüm ve Sınıfına Göre Haftalık Ders Programı
    $stmtSchedule = $pdo->prepare("
        SELECT p.*, d.ders_kodu, d.ders_adi, d.kredi
        FROM ders_programi p
        JOIN dersler d ON p.ders_id = d.id
        WHERE p.bolum = ? AND (p.sinif = ? OR p.sinif IS NULL OR p.sinif = '')
        ORDER BY FIELD(p.gun, 'Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'), p.baslangic_saati ASC
    ");
    $stmtSchedule->execute([$student['bolum'], $student['sinif']]);
    $schedule = $stmtSchedule->fetchAll();

    // Eğer tam eşleşen program yoksa aynı bölümün tüm programını çek
    if (empty($schedule)) {
        $stmtScheduleFallback = $pdo->prepare("
            SELECT p.*, d.ders_kodu, d.ders_adi, d.kredi
            FROM ders_programi p
            JOIN dersler d ON p.ders_id = d.id
            WHERE p.bolum = ?
            ORDER BY FIELD(p.gun, 'Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'), p.baslangic_saati ASC
        ");
        $stmtScheduleFallback->execute([$student['bolum']]);
        $schedule = $stmtScheduleFallback->fetchAll();
    }

    jsonResponse('success', [
        'student' => [
            'id' => $student['id'],
            'ogr_no' => $student['ogr_no'],
            'ad' => $student['ad'],
            'soyad' => $student['soyad'],
            'ad_soyad' => $student['ad'] . ' ' . $student['soyad'],
            'bolum' => $student['bolum'],
            'sinif' => $student['sinif'],
            'gpa' => number_format($gpa, 2),
            'toplamKredi' => $toplamKredi,
            'tamamlananKredi' => $tamamlananKredi,
            'gecenDersSayisi' => $gecenDersSayisi,
            'kalanDersSayisi' => $kalanDersSayisi
        ],
        'grades' => $grades,
        'schedule' => $schedule
    ]);
}

// ==========================================
// 5. YÖNETİCİ GENEL İSTATİSTİKLERİ
// ==========================================
if ($action === 'get_stats') {
    $totalStudents = $pdo->query("SELECT COUNT(*) FROM ogrenciler")->fetchColumn();
    $totalCourses = $pdo->query("SELECT COUNT(*) FROM dersler")->fetchColumn();
    $totalGrades = $pdo->query("SELECT COUNT(*) FROM notlar WHERE ortalama IS NOT NULL")->fetchColumn();
    $avgGrade = $pdo->query("SELECT ROUND(AVG(ortalama), 2) FROM notlar WHERE ortalama IS NOT NULL")->fetchColumn() ?: 0;
    $passed = $pdo->query("SELECT COUNT(*) FROM notlar WHERE durum = 'Geçti'")->fetchColumn();
    $failed = $pdo->query("SELECT COUNT(*) FROM notlar WHERE durum = 'Kaldı'")->fetchColumn();
    $totalSchedules = $pdo->query("SELECT COUNT(*) FROM ders_programi")->fetchColumn();

    jsonResponse('success', [
        'data' => [
            'totalStudents' => intval($totalStudents),
            'totalCourses' => intval($totalCourses),
            'totalGrades' => intval($totalGrades),
            'avgGrade' => floatval($avgGrade),
            'passed' => intval($passed),
            'failed' => intval($failed),
            'totalSchedules' => intval($totalSchedules)
        ]
    ]);
}

// ==========================================
// 6. ÖĞRENCİ YÖNETİMİ (LİSTELE, EKLE, SİL)
// ==========================================
if ($action === 'get_students') {
    $stmt = $pdo->query("SELECT id, ogr_no, ad, soyad, bolum, sinif, created_at FROM ogrenciler ORDER BY ogr_no ASC");
    jsonResponse('success', ['data' => $stmt->fetchAll()]);
}

if ($action === 'add_student') {
    $ogr_no = trim($_POST['ogr_no'] ?? '');
    $ad = trim($_POST['ad'] ?? '');
    $soyad = trim($_POST['soyad'] ?? '');
    $bolum = trim($_POST['bolum'] ?? '');
    $sinif = trim($_POST['sinif'] ?? '1. Sınıf');
    $sifre = trim($_POST['sifre'] ?? '123456');

    if (empty($ogr_no) || empty($ad) || empty($soyad) || empty($bolum)) {
        jsonResponse('error', [], 'Lütfen gerekli tüm alanları doldurun.', 400);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO ogrenciler (ogr_no, ad, soyad, bolum, sinif, sifre) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$ogr_no, $ad, $soyad, $bolum, $sinif, $sifre]);
        jsonResponse('success', [], 'Öğrenci başarıyla eklendi!');
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse('error', [], 'Bu öğrenci numarası (' . $ogr_no . ') zaten kayıtlıdır.', 400);
        } else {
            jsonResponse('error', [], 'Kayıt hatası: ' . $e->getMessage(), 500);
        }
    }
}

if ($action === 'delete_student') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse('error', [], 'Geçersiz öğrenci ID.', 400);
    }
    $stmt = $pdo->prepare("DELETE FROM ogrenciler WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse('success', [], 'Öğrenci ve ilgili tüm kayıtları silindi.');
}

// ==========================================
// 7. DERS YÖNETİMİ (LİSTELE, EKLE, SİL)
// ==========================================
if ($action === 'get_courses') {
    $stmt = $pdo->query("SELECT * FROM dersler ORDER BY ders_kodu ASC");
    jsonResponse('success', ['data' => $stmt->fetchAll()]);
}

if ($action === 'add_course') {
    $ders_kodu = strtoupper(trim($_POST['ders_kodu'] ?? ''));
    $ders_adi = trim($_POST['ders_adi'] ?? '');
    $kredi = intval($_POST['kredi'] ?? 3);
    $ogretmen = trim($_POST['ogretmen'] ?? 'Dr. Öğr. Üyesi');

    if (empty($ders_kodu) || empty($ders_adi)) {
        jsonResponse('error', [], 'Ders kodu ve ders adı zorunludur.', 400);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO dersler (ders_kodu, ders_adi, kredi, ogretmen) VALUES (?, ?, ?, ?)");
        $stmt->execute([$ders_kodu, $ders_adi, $kredi, $ogretmen]);
        jsonResponse('success', [], 'Ders başarıyla sisteme eklendi!');
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            jsonResponse('error', [], 'Bu ders kodu (' . $ders_kodu . ') zaten kayıtlıdır.', 400);
        } else {
            jsonResponse('error', [], 'Ders ekleme hatası: ' . $e->getMessage(), 500);
        }
    }
}

if ($action === 'delete_course') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse('error', [], 'Geçersiz ders ID.', 400);
    }
    $stmt = $pdo->prepare("DELETE FROM dersler WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse('success', [], 'Ders ve ilgili notlar silindi.');
}

// ==========================================
// 8. NOT YÖNETİMİ (LİSTELE, KAYDET/DÜZENLE, SİL)
// ==========================================
if ($action === 'get_grades') {
    $sql = "SELECT no.*, o.ogr_no, o.ad, o.soyad, o.bolum, o.sinif, d.ders_kodu, d.ders_adi, d.kredi 
            FROM notlar no
            JOIN ogrenciler o ON no.ogrenci_id = o.id
            JOIN dersler d ON no.ders_id = d.id
            ORDER BY o.ogr_no ASC, d.ders_kodu ASC";
    $stmt = $pdo->query($sql);
    jsonResponse('success', ['data' => $stmt->fetchAll()]);
}

if ($action === 'save_grade') {
    $ogrenci_id = intval($_POST['ogrenci_id'] ?? 0);
    $ders_id = intval($_POST['ders_id'] ?? 0);
    $vizeRaw = $_POST['vize'] ?? '';
    $finalRaw = $_POST['final'] ?? '';

    $vize = ($vizeRaw !== '' && $vizeRaw !== null) ? floatval($vizeRaw) : null;
    $final = ($finalRaw !== '' && $finalRaw !== null) ? floatval($finalRaw) : null;

    if ($ogrenci_id <= 0 || $ders_id <= 0) {
        jsonResponse('error', [], 'Öğrenci ve ders seçimi zorunludur.', 400);
    }

    if (($vize !== null && ($vize < 0 || $vize > 100)) || ($final !== null && ($final < 0 || $final > 100))) {
        jsonResponse('error', [], 'Notlar 0 ile 100 arasında olmalıdır.', 400);
    }

    $calc = hesaplaNot($vize, $final);

    // Kayıt var mı kontrol et
    $stmt = $pdo->prepare("SELECT id FROM notlar WHERE ogrenci_id = ? AND ders_id = ?");
    $stmt->execute([$ogrenci_id, $ders_id]);
    $existing = $stmt->fetch();

    if ($existing) {
        $update = $pdo->prepare("
            UPDATE notlar 
            SET vize = ?, final = ?, ortalama = ?, harf_notu = ?, durum = ? 
            WHERE id = ?
        ");
        $update->execute([$vize, $final, $calc['ortalama'], $calc['harf'], $calc['durum'], $existing['id']]);
        jsonResponse('success', ['calc' => $calc], 'Not başarıyla güncellendi!');
    } else {
        $insert = $pdo->prepare("
            INSERT INTO notlar (ogrenci_id, ders_id, vize, final, ortalama, harf_notu, durum) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $insert->execute([$ogrenci_id, $ders_id, $vize, $final, $calc['ortalama'], $calc['harf'], $calc['durum']]);
        jsonResponse('success', ['calc' => $calc], 'Not başarıyla sisteme kaydedildi!');
    }
}

if ($action === 'delete_grade') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse('error', [], 'Geçersiz not ID.', 400);
    }
    $stmt = $pdo->prepare("DELETE FROM notlar WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse('success', [], 'Not kaydı silindi.');
}

// ==========================================
// 9. DERS PROGRAMI YÖNETİMİ
// ==========================================
if ($action === 'get_schedule') {
    $bolum = trim($_GET['bolum'] ?? '');
    $sinif = trim($_GET['sinif'] ?? '');

    $sql = "SELECT p.*, d.ders_kodu, d.ders_adi, d.kredi 
            FROM ders_programi p
            JOIN dersler d ON p.ders_id = d.id";
    $params = [];

    if (!empty($bolum) && !empty($sinif)) {
        $sql .= " WHERE p.bolum = ? AND p.sinif = ?";
        $params = [$bolum, $sinif];
    } elseif (!empty($bolum)) {
        $sql .= " WHERE p.bolum = ?";
        $params = [$bolum];
    }

    $sql .= " ORDER BY FIELD(p.gun, 'Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'), p.baslangic_saati ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    jsonResponse('success', ['data' => $stmt->fetchAll()]);
}

if ($action === 'add_schedule') {
    $ders_id = intval($_POST['ders_id'] ?? 0);
    $bolum = trim($_POST['bolum'] ?? '');
    $sinif = trim($_POST['sinif'] ?? '1. Sınıf');
    $gun = trim($_POST['gun'] ?? 'Pazartesi');
    $baslangic_saati = trim($_POST['baslangic_saati'] ?? '09:00');
    $bitis_saati = trim($_POST['bitis_saati'] ?? '11:45');
    $derslik = trim($_POST['derslik'] ?? 'Derslik 101');
    $ogretmen = trim($_POST['ogretmen'] ?? '');

    if ($ders_id <= 0 || empty($bolum) || empty($baslangic_saati) || empty($bitis_saati) || empty($derslik)) {
        jsonResponse('error', [], 'Lütfen ders, bölüm, gün, saat ve derslik alanlarını doldurun.', 400);
    }

    // Eğer öğretmen girilmediyse dersin varsayılan hocasını al
    if (empty($ogretmen)) {
        $dStmt = $pdo->prepare("SELECT ogretmen FROM dersler WHERE id = ?");
        $dStmt->execute([$ders_id]);
        $ogretmen = $dStmt->fetchColumn() ?: 'Öğretim Görevlisi';
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO ders_programi (ders_id, bolum, sinif, gun, baslangic_saati, bitis_saati, derslik, ogretmen) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$ders_id, $bolum, $sinif, $gun, $baslangic_saati, $bitis_saati, $derslik, $ogretmen]);
        jsonResponse('success', [], 'Ders programı başarıyla eklendi!');
    } catch (PDOException $e) {
        jsonResponse('error', [], 'Program ekleme hatası: ' . $e->getMessage(), 500);
    }
}

if ($action === 'delete_schedule') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        jsonResponse('error', [], 'Geçersiz program ID.', 400);
    }
    $stmt = $pdo->prepare("DELETE FROM ders_programi WHERE id = ?");
    $stmt->execute([$id]);
    jsonResponse('success', [], 'Ders programı kaydı başarıyla silindi.');
}

jsonResponse('error', [], 'Geçersiz işlem isteği: ' . htmlspecialchars($action), 404);
